const { CommandInteraction, Client } = require('discord.js');
const { SlashCommandBuilder } = require('discord.js');
const Discord = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('premium')
        .setDescription("Get the bot's premium features")
        .addSubcommand(subcommand =>
            subcommand
                .setName('help')
                .setDescription('Get information about the premium category commands')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('redeem')
                .setDescription('Redeem the premium code')
                .addNumberOption(option => option.setName('code').setDescription('Enter the code').setRequired(false))
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('premiumlist')
                .setDescription('View the people who bought premium')
        )
    ,

    /** 
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */

    run: async (client, interaction, args) => {
        await interaction.deferReply({ fetchReply: true });
        client.loadSubcommands(client, interaction, args);
    },
};

 