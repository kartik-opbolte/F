const { CommandInteraction, Client } = require('discord.js');
const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const Discord = require('discord.js');
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Get help with the bot'),

  /** 
   * @param {Client} client
   * @param {CommandInteraction} interaction
   * @param {String[]} args
   */

  run: async (client, interaction, args) => {
    const toUpperCase = (string) => string.charAt(0).toUpperCase() + string.slice(1);
    const commad = (name) => {
      let text = `*To Run Any Command Type*: \`/${name} {Sub Command Name}\``
      let text2 = client.commands.filter(x => x.data.name == name).map((x) => x.data.options.map((c) => '`' + c.name + '` - ' + c.description).join("\n"));
      return text2 + `\n\n` + text
    }
    
    let em1 = new EmbedBuilder()
      .setAuthor({ name: `${client.user.username}\'s Help Menu`, iconURL: client.user.displayAvatarURL({ format: "png" }), url: "https://dsc.gg/teamcrypts" })
      .setImage(`https://i.stack.imgur.com/Fzh0w.png`)
      .setColor(`#000005`)
      .addFields([
        {
          name: "Configuration [1-9]",
          value: `>>> <:snowflake1:1083405917086810132>┆AFK
          <:annoucement:1083407865487839304>┆Announcement
          <:mod:1083408043326320640>┆Auto mod
          <:settings:1083408039031357580>┆Auto setup
          <:gift:1083408033926877194>┆Birthday
          <:discord_bot:1083408029283778620>┆Bot
          <:casino:1083408024309354526>┆Casino
          <:configuration:1083408018537992264>┆Configuration
          <:stars:1083408014201065532>┆Custom commands`,
          inline: true
        },
        {
          name: "Admin [19-27]",
          value: `>>> <:rocket:1083412692846514237>┆Leveling
          <:messages:1083412688648011789>┆Messages
          <:admin:1083412686018199582>┆Moderation
          <:music:1083412683132510270>┆Music
          <:notes:1083412657173975201>┆Notepad
          <:member:1083412647573213184>┆Profile
          <:radio:1083412595408654356>┆Radio
          <:reaction_role:1083412447135805451>┆Reaction roles
          <:search:1083412404697829419>┆Search`,
          inline: true
        },
        {
          name: "\u200b",
          value: "\u200b",
          inline: true
        },
        {
          name: "Fun [10-18]",
          value: `>>> <:dcredits:1083415451750637568>┆Dcredits
          <:economy:1083415449338921030>┆Economy
          <:family:1083415445664714812>┆Family
          <:fun:1083415441424273450>┆Fun
          <:games:1083415439109005405>┆Games
          <:giveaways:1083415435254452355>┆Giveaway
          <:discord:1083415431131430993>┆Guild settings
          <:photos:1083415428681965618>┆Images
          <:add:1083415424605106268>┆Invites`,
          inline: true
        }, {
          name: "Setup [28-36]",
          value: `>>> <:stats:1083418081478578206>┆Server Stats
          <:settings:1083408039031357580>┆Setup
          <:soundboard:1083418076650938420>┆Soundboard
          <:hashtag:1083418071621980241>┆Sticky messages
          <:heart:1083418066270044282>┆Suggestions
          <:bell:1083418062457417789>┆Thanks
          <:ticket:1083418057608810587>┆Tickets
          <:admin:1083412686018199582>┆Tools
          <:radio:1083412595408654356>┆Voice`,
          inline: true
        },
        {
          name: "\u200b",
          value: "\u200b",
          inline: true
        },
        {
          name: ` `,
          value: ` `
        },        
        {
          name: `🔗┆Links`,
          value: `[Website](https://www.mercurymusic.cf/) | [Invite](${client.config.discord.botInvite}) | [Vote](https://discordbotlist.com/bots/mercury)`
        },
      ])
      .setImage(`https://share.creavite.co/ai5GVxPbzqJ4zXZG.gif`)


    let startButton = new ButtonBuilder().setStyle(2).setEmoji(`<:arrow_leftt:1083443493847965757>`).setCustomId('start'),
      backButton = new ButtonBuilder().setStyle(2).setEmoji(`<:arrow_left:1083441001609318451>`).setCustomId('back'),
      forwardButton = new ButtonBuilder().setStyle(2).setEmoji(`<:arrow_right:1083441031992856607>`).setCustomId('forward'),
      endButton = new ButtonBuilder().setStyle(2).setEmoji(`<:arrow_rightt:1083443559736287262>`).setCustomId('end')
     

    const options = [{ label: 'Overview', value: '0' }]
    const options2 = []
    
    let counter = 0
    let counter2 = 25
    require("fs").readdirSync(`${process.cwd()}/src/commands`).slice(0, 24).forEach(dirs => {
      counter++
      const opt = {
        label: toUpperCase(dirs.replace("-", " ")),
        value: `${counter}`
      }
      options.push(opt)
    })
    require("fs").readdirSync(`${process.cwd()}/src/commands`).slice(25, 37).forEach(dirs => {
      counter2++
      const opt = {
        label: toUpperCase(dirs.replace("-", " ")),
        value: `${counter2}`
      }
      options2.push(opt)
    })
    
    let menu = new StringSelectMenuBuilder().setPlaceholder('Change page').setCustomId('pagMenu').addOptions(options).setMaxValues(1).setMinValues(1),
      menu2 = new StringSelectMenuBuilder().setPlaceholder('Change page').setCustomId('pagMenu2').addOptions(options2).setMaxValues(1).setMinValues(1)

    const allButtons = [startButton.setDisabled(true), backButton.setDisabled(true), forwardButton.setDisabled(false), endButton.setDisabled(false)]

    let group1 = new ActionRowBuilder().addComponents(menu)
    let group2 = new ActionRowBuilder().addComponents(allButtons)
    let group3 = new ActionRowBuilder().addComponents(menu2)

    const components = [group2, group1, group3]
    
    let helpMessage = await interaction.reply({
      content: `Click on the buttons to change page`,
      embeds: [em1],
      components: components,
    })
    
    const collector = helpMessage.createMessageComponentCollector((button) => button.user.id === interaction.user.id, { time: 60e3 });

    var embeds = [em1]
    
    require("fs").readdirSync(`${process.cwd()}/src/commands`).forEach(dirs => {embeds.push(new EmbedBuilder().setAuthor({name: toUpperCase(dirs),iconURL: client.user.displayAvatarURL({format:"png"}),url:`h`+`tt`+`ps:`+`//`+`d`+`s`+`c`+`.`+`gg`+`/u`+`o`+`a`+`i`+`o`}).setDescription(`${commad(dirs)}`))})

    let currentPage = 0

    collector.on('collect', async (b) => {
      if (b.user.id !== interaction.user.id)
        return b.reply({
          content: `**You Can't Use it\n**`,
          ephemeral: true
        });
      switch (b.customId) {
        case 'start':
          currentPage = 0
          group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(true), backButton.setDisabled(true), forwardButton.setDisabled(false), endButton.setDisabled(false)])
          b.update({ embeds: [embeds[currentPage]], components: components })
          break;
        case 'back':
          --currentPage;
          if (currentPage === 0) { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(true), backButton.setDisabled(true), forwardButton.setDisabled(false), endButton.setDisabled(false)]) } else { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(false), endButton.setDisabled(false)]) }
          b.update({ embeds: [embeds[currentPage]], components: components })
          break;
        case 'forward':
          currentPage++;
          if (currentPage === embeds.length - 1) { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(true), endButton.setDisabled(true)]) } else { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(false), endButton.setDisabled(false)]) }
          b.update({ embeds: [embeds[currentPage]], components: components })
          break;
        case 'end':
          currentPage = embeds.length - 1;
          group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(true), endButton.setDisabled(true)])
          b.update({ embeds: [embeds[currentPage]], components: components })
          break;
        case 'pagMenu':
          currentPage = parseInt(b.values[0])
          if (currentPage === 0) { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(true), backButton.setDisabled(true), forwardButton.setDisabled(false), endButton.setDisabled(false)]) } else if (currentPage === embeds.length - 1) { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(true), endButton.setDisabled(true)]) } else { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(false), endButton.setDisabled(false)]) }
          b.update({ embeds: [embeds[currentPage]], components: components })
          break;
        case 'pagMenu2':
          currentPage = parseInt(b.values[0])
          if (currentPage === 0) { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(true), backButton.setDisabled(true), forwardButton.setDisabled(false), endButton.setDisabled(false)]) } else if (currentPage === embeds.length - 1) { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(true), endButton.setDisabled(true)]) } else { group2 = new ActionRowBuilder().addComponents([startButton.setDisabled(false), backButton.setDisabled(false), forwardButton.setDisabled(false), endButton.setDisabled(false)]) }
          b.update({ embeds: [embeds[currentPage]], components: components })
          break;
        default:
          currentPage = 0
          b.update({ embeds: [embeds[currentPage]], components: null })
          break;
      }
    });

    collector.on('end', b => {
      b.update({ embeds: [helpMessage.embeds[0]], content: [], components: [] })
    });

    collector.on('error', (e) => console.log(e));

    embeds.map((embed, index) => {
      embed.setColor("#000005").setImage(`https://i.stack.imgur.com/Fzh0w.png`)
        .setFooter({ text: `Page ${index + 1} / ${embeds.length}`, iconURL: client.user.displayAvatarURL() });
    })

  },
};