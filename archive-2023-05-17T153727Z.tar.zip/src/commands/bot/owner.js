const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    client.embed({
        title: `📘・Owner information`,
        desc: `____________________________`,
        thumbnail: client.user.avatarURL({ dynamic: true, size: 1024 }),
        fields: [{
            name: "👑┆Owner name",
            value: `Ninju`,
            inline: true,
        },
        {
            name: "🏷┆Discord tag",
            value: "<@743317832434974811>",
            inline: true,
        },
        {
            name: "🏢┆Organization",
            value: `Team Crypts`,
            inline: true,
        },
        {
            name: "🌐┆Website",
            value: `[https://coolblox6.cf](https://coolblox6.cf)`,
            inline: true,
        }],
        type: 'editreply'
    }, interaction)
}

 