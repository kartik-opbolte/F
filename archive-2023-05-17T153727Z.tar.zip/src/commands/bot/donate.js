const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    let row = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
                .setLabel("Ninju Portfolio")
                .setURL("https://coolblox6.cf")
                .setStyle(Discord.ButtonStyle.Link),
        );

    client.embed({
        title: `${client.user.username}・Donate`,
        desc: '_____ \n\nClick the button below for the donation page \n**Pay attention! donation is not required**',
        thumbnail: client.user.avatarURL({ dynamic: true }),
        url: "https://www.buymeacoffee.com/ninju",
        components: [row],
        type: 'editreply'
    }, interaction)
}

 