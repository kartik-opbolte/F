const Discord = require('discord.js');

const webhookClient = new Discord.WebhookClient({
    id: "1081891214237900910",
    token: "ha9B_GxLOT9kETuh7LQ1htzyY9eJsygvSTqVFvM9wRsP71xZcl3JzHbxTMmfZ-cwyo7h",
});

module.exports = async (client, interaction, args) => {
    const feedback = interaction.options.getString('feedback');

    const embed = new Discord.EmbedBuilder()
        .setTitle(`📝・New feedback!`)
        .addFields(
            { name: "User", value: `${interaction.user} (${interaction.user.tag})`, inline: true },
        )
        .setDescription(`${feedback}`)
        .setColor(client.config.colors.normal)
    webhookClient.send({
        username: 'Galaxies Feedback',
        embeds: [embed],
    });

    client.succNormal({ 
        text: `Feedback successfully sent to the developers`,
        type: 'editreply'
    }, interaction);
}

 