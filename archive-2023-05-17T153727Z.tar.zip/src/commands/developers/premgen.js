const Discord = require('discord.js');
var voucher_codes = require('voucher-code-generator');

module.exports = async (client, interaction, args) => {

    const codePremium = voucher_codes.generate({
        pattern: "####-####-####",
    });

    client.succNormal({ text: `I have generated a code and have it sent to your DM`, type: 'editreply' }, interaction);

    client.succNormal({
        text: `Your generated Code`,
        fields: [
            {
                name: "✌️┇Premium Code",
                value: `${codePremium}`,
                inline: true,
            },
            {
                name: "👣┇Length",
                value: `12`,
                inline: true,
            }
        ]
    }, interaction.user)

}

 