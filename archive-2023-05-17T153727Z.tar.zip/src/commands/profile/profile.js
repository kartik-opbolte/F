const model = require('../../database/models/badge');
const Schema = require('../../database/models/profile');
const CreditsSchema = require("../../database/models/votecredits");

module.exports = async (client, interaction, args) => {

    const badgeFlags = {
        DEVELOPER: client.emotes.badges.developer,
        EVENT: client.emotes.badges.event,
        BOOSTER: client.emotes.badges.booster,
        BUGS: client.emotes.badges.bug,
        MANAGEMENT: client.emotes.badges.management,
        PREMIUM: client.emotes.badges.premium,
        SUPPORTER: client.emotes.badges.supporter,
        TEAM: client.emotes.badges.team,
        BOOSTER: client.emotes.badges.booster,
        PARTNER: client.emotes.badges.partner,
        VOTER: client.emotes.badges.voter,
        SUPPORT: client.emotes.badges.support,
        MODERATOR: client.emotes.badges.moderator,
        DESIGNER: client.emotes.badges.designer,
        MARKETING: client.emotes.badges.marketing,
        ACTIVE: client.emotes.badges.active,
        VIP: client.emotes.badges.vip
    }

    const flags = {
        ActiveDeveloper: "👨‍💻・Active Developer",
        BugHunterLevel1: "🐛・Discord Bug Hunter",
        BugHunterLevel2: "🐛・Discord Bug Hunter",
        CertifiedModerator: "👮‍♂️・Certified Moderator",
        HypeSquadOnlineHouse1: "🏠・House Bravery Member",
        HypeSquadOnlineHouse2: "🏠・House Brilliance Member",
        HypeSquadOnlineHouse3: "🏠・House Balance Member",
        HypeSquadEvents: "🏠・HypeSquad Events",
        PremiumEarlySupporter: "👑・Early Supporter",
        Partner: "👑・Partner",
        Quarantined: "🔒・Quarantined", // Not sure if this is still a thing
        Spammer: "🔒・Spammer", // Not sure if this one works
        Staff: "👨‍💼・Discord Staff",
        TeamPseudoUser: "👨‍💼・Discord Team",
        VerifiedBot: "🤖・Verified Bot",
        VerifiedDeveloper: "👨‍💻・(early)Verified Bot Developer",
    }

    const user = interaction.options.getUser('user') || interaction.user;

    Schema.findOne({ User: user.id }, async (err, data) => {
        if (data) {
            let Badges = await model.findOne({ User: user.id });

            let credits = 0;
            const creditData = await CreditsSchema.findOne({ User: user.id });

            if (Badges && Badges.FLAGS.includes("DEVELOPER")) {
                credits = "∞";
            }
            else if (creditData) {
                credits = creditData.Credits;
            }

            if (!Badges) Badges = { User: user.id };

            const userFlags = user.flags ? user.flags.toArray() : [];

            client.embed({
                title: `${client.user.username}・Profile`,
                desc: '_____',
                thumbnail: user.avatarURL({ dynamic: true }),
                fields: [{
                    name: "<:member:1083412647573213184>┆User",
                    value: user.username,
                    inline: true
                },
                {
                    name: "<:hashtag:1083418071621980241>┆Discriminator",
                    value: user.discriminator,
                    inline: true
                },
                {
                    name: "<:id:1086617048269991998>┆ID",
                    value: user.id,
                    inline: true
                },
                {
                    name: "<:member:1083412647573213184>┆Gender",
                    value: `${data.Gender || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:family:1083415445664714812>┆Age",
                    value: `${data.Age || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:gift:1083408033926877194>┆Birthday",
                    value: `${data.Birthday || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:designer:1090315304338464858>┆Favorite color",
                    value: `${data.Color || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:pet:1090327377961295952>┆Favorite pets",
                    value: `${data.Pets.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:food:1090327705091846145>┆Favorite food",
                    value: `${data.Food.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:radio:1083412595408654356>┆Favorite songs",
                    value: `${data.Songs.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:dcredits:1083415451750637568>┆Favorite artists",
                    value: `${data.Artists.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<a:movie:1090329503550677073>┆Favorite movies",
                    value: `${data.Movies.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:member:1083412647573213184>┆Favorite actors",
                    value: `${data.Actors.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:flag:1090328657668620468>┆Origin",
                    value: `${data.Orgin || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:games:1083415439109005405>┆Hobby's",
                    value: `${data.Hobbys.join(', ') || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:globe:1086617035477352448>┆Status",
                    value: `${data.Status || 'Not set'}`,
                    inline: true
                },
                {
                    name: "<:discord_bot:1083408029283778620>┆Bot Badges",
                    value: `${Badges.FLAGS ? Badges.FLAGS.map(flag => badgeFlags[flag]).join(' ') : 'None'}`,
                    inline: true
                },
                {
                    name: "<:discord:1083415431131430993>┆Discord Badges",
                    value: `${userFlags.length ? userFlags.map(flag => flags[flag]).join(', ') : 'None' || 'None'}`,
                    inline: true
                },
                {
                    name: "<:card:1090321811264245860>┆Dcredits",
                    value: `${credits || 'None'}`,
                    inline: true
                },
                {
                    name: "<:info1:1086617052674019428>┆About me",
                    value: `${data.Aboutme || 'Not set'}`,
                    inline: false
                },], type: 'editreply'
            }, interaction);
        }
        else {
            return client.errNormal({ error: "No profile found! Open a profile with /profile create", type:'editreply' }, interaction);
        }
    })
}

 