module.exports = async (e) => {
    console.error(e);
}